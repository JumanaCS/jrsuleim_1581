public class Room{
	private String name;
	private String description;

	private Room north;
	private Room east;
	private Room west;
	private Room south;

	public Room(String name, String description){
		this.name = name;
		this.description = description;
	}

	public void setExits(Room n, Room e, Room w, Room s){
		north = n;
		east = e;
		west = w;
		south = s;
	}

	public String getName(){
		return this.name;
	}

	public Room getNorth(){
		if(this.north == null){
			return null;
		}
		else{
		return this.north;
		}
	}

	public Room getEast(){
		if(this.east == null){
			return null;
		}
		else{
		return this.east;
		}
	}

	public Room getWest(){
		if(this.west == null){
			return null;
		}
		else{
		return this.west;
		}
	}

	public Room getSouth(){
		if(this.south == null){
			return null;
		}
		else{
		return this.south;
		}
	}

	public String getExits(){
		String roomExits = "";

		if(getNorth() != null){
			roomExits = String.format("[N]orth: %s\n", getNorth().getName());
		}
		if(getEast() != null){
			roomExits += String.format("[E]ast: %s\n", getEast().getName());
		}
		if(getWest() != null){
			roomExits += String.format("[W]est: %s\n", getWest().getName());
		}
		if(getSouth() != null){
			roomExits += String.format("[S]outh: %s\n", getSouth().getName());
		}

		return roomExits;
	}

	public String toString(){
		return "[" + getName() + "]" + "\n" + this.description + "\n" + getExits();
	}
}