public class Monster{
	private String name;
	private int health;
	private int strength;
	private int xP;

	public Monster(String name, int health, int strength, int xP){
		this.name = name;
		this.health = health;
		this.strength = strength;
		this.xP = xP;
	}	

	public void attack(Player hero){
		hero.takeDamage(strength);
	}

	public int getHealth(){
		return this.health;
	}

	public String getName(){
		return this.name;
	}

	public int getStrength(){
		return this.strength;
	}

	public int getXP(){
		return xP;
	}

	static Monster spawn(String type){
		Monster mon = null;

		if(type.equals("goblin")){
			mon = new Monster("goblin", 60, 8, 1);
		}
		else if(type.equals("orc")){
			mon = new Monster("orc", 100, 12, 3);
		}
		else if(type.equals("troll")){
			mon = new Monster("troll", 150, 15, 5);
		}
		return mon;
	}

	public void takeDamage(int damage){
		if(health - damage > 0){
			health =+ damage;
		}
		else if(health - damage <= 0){
			health = 0;
		}
	}

	public String toString(){
		return String.format("[%s] HP:%d, AP:%d", name, health, strength);
	}
}