public class CommissionEmployee extends Employee{
	private double commissionRate;
	private double totalSales;

	public CommissionEmployee(String name, double rate, double sales){
		super(name);
		this.commissionRate = rate;
		this.totalSales = sales;
	}

	public double getPayment(){
		return this.commissionRate * this.totalSales;
	}

	public String toString(){
		String employeeName = super.toString();
		return String.format("%s, commission:%.02f%% @ $%.02f sales", employeeName, this.commissionRate, this.totalSales);
	}
}